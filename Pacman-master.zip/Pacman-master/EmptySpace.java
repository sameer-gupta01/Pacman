package ghost;
import processing.core.PImage;

public class EmptySpace extends GameEntity {
    
    public EmptySpace(PImage sprite, boolean isSolid, int pixelX, int pixelY) {
        super(sprite, isSolid, pixelX, pixelY);
    }

}