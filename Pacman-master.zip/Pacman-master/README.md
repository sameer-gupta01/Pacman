# Pacman project built using Gradle. The most interesting files are Ghost.java and Waka.java, as they contain the bulk of the logic for the main elements of the game.
